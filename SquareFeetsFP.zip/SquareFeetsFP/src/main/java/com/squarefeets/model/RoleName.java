package com.squarefeets.model;

public enum RoleName {
    ROLE_CUSTOMER,
    ROLE_ADMIN,
    ROLE_BUILDER
}
